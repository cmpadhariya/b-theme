window.onload = function() {
	document.getElementById( 'comment' ).setAttribute( 'placeholder', 'Your comment here' );
	document.getElementById( 'author' ).setAttribute( 'placeholder', 'Type name here' );
	document.getElementById( 'email' ).setAttribute( 'placeholder', 'you@example.com' );
	document.getElementById( 'url' ).setAttribute( 'placeholder', 'example.com' );
};
